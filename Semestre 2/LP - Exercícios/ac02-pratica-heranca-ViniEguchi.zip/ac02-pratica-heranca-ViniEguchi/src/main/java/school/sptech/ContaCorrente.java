package school.sptech;

import java.lang.reflect.Field;
import java.util.Objects;

public class ContaCorrente {

    private String numero;
    private String titular;
    private Double saldo;

    public ContaCorrente() {
        this.saldo = 0.0;
    }

    public ContaCorrente(String titular, String numero) {
        this.titular = titular;
        this.numero = numero;
        this.saldo = 0.0;
    }

    public void depositar(Double valor) {
        if (valor == null || valor <= 0) {
            return;
        }

        saldo += valor;
    }

    public void sacar(Double valor) {
        if (valor == null || valor <= 0 || valor > saldo) {
            return;
        }

        saldo -= valor;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    // <editor-fold desc="Não alterar - Será usado nos testes" state="collapsed">
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        ContaCorrente that = (ContaCorrente) o;

        try {
            Class<ContaCorrente> clazz = ContaCorrente.class;
            Field numero = clazz.getDeclaredField("numero");
            Field titular = clazz.getDeclaredField("titular");
            Field saldo = clazz.getDeclaredField("saldo");

            return Objects.equals(numero.get(this), numero.get(that)) && Objects.equals(titular.get(this), titular.get(that)) && Objects.equals(saldo.get(this), saldo.get(that));
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }
    //</editor-fold>
}

package school.sptech;

import java.lang.reflect.Field;
import java.util.Objects;

public class ContaCorrentePlus extends ContaCorrente {

    private Integer pontos;

    public ContaCorrentePlus() {
        this.pontos = 0;
    }

    public ContaCorrentePlus(String titular, String numero) {
        super(titular, numero);
        this.pontos = 0;
    }

    public void depositar(Double valor) {
        if (valor == null || valor <= 0) {
            return;
        }

        Double novoSaldo = getSaldo() + valor;
        setSaldo(novoSaldo);
        pontos += (int) (valor / 5);
    }

    public Integer getPontos() {
        return pontos;
    }

    public void setPontos(Integer pontos) {
        this.pontos = pontos;
    }

    // <editor-fold desc="Não alterar - Será usado nos testes" state="collapsed">
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        ContaCorrentePlus that = (ContaCorrentePlus) o;

        try {
            Class<ContaCorrentePlus> clazz = ContaCorrentePlus.class;
            Field pontos = clazz.getDeclaredField("pontos");
            return Objects.equals(pontos.get(this), pontos.get(that));
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }
    //</editor-fold>
}

package school.sptech;

import java.util.ArrayList;
import java.util.List;

public class Banco {
    private String nome;
    private List<ContaCorrente> contas;

    public Banco() {
        contas = new ArrayList<>();
    }

    public Banco(String nome) {
        this.nome = nome;
        contas = new ArrayList<>();
    }

    public void criarConta(String numero, String titular) {
        if (numero == null || numero.isBlank() || titular == null || titular.isBlank()) {
            return;
        }

        contas.add(new ContaCorrente(titular, numero));
    }

    public void criarContaPlus(String numero, String titular) {
        if (numero == null || numero.isBlank() || titular == null || titular.isBlank()) {
            return;
        }

        contas.add(new ContaCorrentePlus(titular, numero));
    }

    public ContaCorrente buscarPorNumero(String numero) {
        for (ContaCorrente conta : contas) {
            if (conta.getNumero().equals(numero)) {
                return conta;
            }
        }

        return null;
    }

    public void removerPorNumero(String numero) {
        for (ContaCorrente conta : contas) {
            if (conta.getNumero().equals(numero)) {
                contas.remove(conta);
                break;
            }
        }
    }

    public List<ContaCorrentePlus> buscarContasPlus() {
        List<ContaCorrentePlus> resultado = new ArrayList<>();

        for (ContaCorrente conta : contas) {
            if (conta instanceof ContaCorrentePlus plus) {
                resultado.add(plus);
            }
        }

        return resultado;
    }

    public List<ContaCorrentePlus> buscarContasComPontosMaior(Integer pontos) {
        List<ContaCorrentePlus> resultado = new ArrayList<>();

        for (ContaCorrente conta : contas) {
            if (conta instanceof ContaCorrentePlus plus) {
                if (plus.getPontos() > pontos) {
                    resultado.add(plus);
                }
            }
        }

        return resultado;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<ContaCorrente> getContas() {
        return contas;
    }

    public void setContas(List<ContaCorrente> contas) {
        this.contas = contas;
    }
}

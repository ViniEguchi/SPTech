package school.sptech.factory;

import school.sptech.ContaCorrente;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class ContaCorrenteFactory {

  public static Map<String, Field> campos() throws ReflectiveOperationException {
    Class<ContaCorrente> clazz = ContaCorrente.class;

    Map<String, Field> mapCampos = new HashMap<>();
    String[] nomeCampos = { "numero", "titular", "saldo" };

    for (String campoNome : nomeCampos) {
      Field campo = clazz.getDeclaredField(campoNome);
      campo.trySetAccessible();

      mapCampos.put(campoNome, campo);
    }

    return mapCampos;
  }

  public static Object build(String numero, String titular, Double saldo) throws ReflectiveOperationException {
    Object obj = new ContaCorrente();
    campos().get("numero").set(obj, numero);
    campos().get("titular").set(obj, titular);
    campos().get("saldo").set(obj, saldo);

    return obj;
  }
}

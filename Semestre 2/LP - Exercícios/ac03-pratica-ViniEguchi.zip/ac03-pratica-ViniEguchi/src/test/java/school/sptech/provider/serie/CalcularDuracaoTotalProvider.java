package school.sptech.provider.serie;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;

import java.util.stream.Stream;

import static school.sptech.fixture.ReviewsFixture.getReviewListFromScore;

public class CalcularDuracaoTotalProvider implements ArgumentsProvider {

  @Override
  public Stream<? extends Arguments> provideArguments(ExtensionContext extensionContext) throws Exception {
    return Stream.of(
        Arguments.of("Breaking Bad", getReviewListFromScore(95), 16, "DRAMA", 62, 5, 50, 3100),
        Arguments.of("Game of Thrones", getReviewListFromScore(93), 18, "DRAMA", 60, 8, 60, 3600),
        Arguments.of("The Walking Dead", getReviewListFromScore(82), 11, "TERROR", 45, 11, 41, 1845),
        Arguments.of("Stranger Things", getReviewListFromScore(87), 3, "TERROR", 50, 3, 50, 2500),
        Arguments.of("The Big Bang Theory", getReviewListFromScore(81), 12, "COMEDIA", 280, 12, 22, 6160),
        Arguments.of("Friends", getReviewListFromScore(89), 10, "COMEDIA", 234, 10, 22, 5148),
        Arguments.of("How I Met Your Mother", getReviewListFromScore(83), 9, "COMEDIA", 208, 9, 22, 4576),
        Arguments.of("The Office", getReviewListFromScore(89), 9, "COMEDIA", 188, 9, 22, 4136),
        Arguments.of("Grey's Anatomy", getReviewListFromScore(76), 17, "DRAMA", 431, 20, 40, 17240),
        Arguments.of("Supernatural", getReviewListFromScore(84), 15, "TERROR", 327, 15, 42, 13734),
        Arguments.of("The Originals", getReviewListFromScore(82), 5, "TERROR", 50, 5, 50, 2500)
    );
  }
}

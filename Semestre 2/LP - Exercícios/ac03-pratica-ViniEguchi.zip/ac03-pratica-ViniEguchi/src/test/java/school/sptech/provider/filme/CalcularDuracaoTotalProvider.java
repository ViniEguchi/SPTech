package school.sptech.provider.filme;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;

import java.util.stream.Stream;

import static school.sptech.fixture.ReviewsFixture.getReviewListFromScore;

public class CalcularDuracaoTotalProvider implements ArgumentsProvider {

  @Override
  public Stream<? extends Arguments> provideArguments(ExtensionContext extensionContext) throws Exception {
    return Stream.of(
        Arguments.of("Um sonho de liberdade", getReviewListFromScore(95), 16, "DRAMA", "Frank Darabont", 142, 10, 152),
        Arguments.of("O Poderoso Chefão", getReviewListFromScore(90), 14, "DRAMA", "Francis Ford Coppola", 175, 10, 185),
        Arguments.of("O Poderoso Chefão II", getReviewListFromScore(89), 14, "DRAMA", "Francis Ford Coppola", 202, 10, 212),
        Arguments.of("Batman: O Cavaleiro das Trevas", getReviewListFromScore(92), 12, "ACAO", "Christopher Nolan", 152, 10, 162),
        Arguments.of("12 Homens e uma Sentença", getReviewListFromScore(89), 12, "DRAMA", "Sidney Lumet", 96, 10, 106),
        Arguments.of("Sexta-Feira 13", getReviewListFromScore(65), 18, "TERROR", "Sean S. Cunningham", 95, 10, 105),
        Arguments.of("A Lista de Schindler", getReviewListFromScore(89), 14, "DRAMA", "Steven Spielberg", 195, 10, 205),
        Arguments.of("O Senhor dos Anéis: O Retorno do Rei", getReviewListFromScore(89), 12, "ACAO", "Peter Jackson", 201, 10, 211),
        Arguments.of("O Exorcista", getReviewListFromScore(80), 18, "TERROR", "William Friedkin", 122, 10, 132),
        Arguments.of("Pulp Fiction: Tempo de Violência", getReviewListFromScore(89), 18, "DRAMA", "Quentin Tarantino", 154, 10, 164),
        Arguments.of("O Senhor dos Anéis: A Sociedade do Anel", getReviewListFromScore(88), 12, "ACAO", "Peter Jackson", 178, 10, 188),
        Arguments.of("Forrest Gump: O Contador de Histórias", getReviewListFromScore(88), 12, "DRAMA", "Robert Zemeckis", 142, 10, 152),
        Arguments.of("O Iluminado", getReviewListFromScore(84), 16, "TERROR", "Stanley Kubrick", 146, 10, 156)
    );
  }
}

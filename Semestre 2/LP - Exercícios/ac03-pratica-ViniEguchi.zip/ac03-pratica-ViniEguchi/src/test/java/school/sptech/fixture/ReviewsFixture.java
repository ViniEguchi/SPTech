package school.sptech.fixture;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ReviewsFixture {

  public static List<Boolean> getReviewListFromScore(Integer score) {
    int negativeReviews = 100 - score;

    List<Boolean> reviews = new ArrayList<>();
    reviews.addAll(Collections.nCopies(score, true));
    reviews.addAll(Collections.nCopies(negativeReviews, false));
    Collections.shuffle(reviews, new Random(42));

    return reviews;
  }
}

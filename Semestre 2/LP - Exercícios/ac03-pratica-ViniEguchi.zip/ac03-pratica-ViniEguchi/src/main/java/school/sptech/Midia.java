package school.sptech;

import java.util.List;

public abstract class Midia {
    protected String nome;
    protected List<Boolean> reviews;
    protected Integer classificacaoEtaria;
    protected Genero genero;

    public Midia() {
    }

    public abstract Integer calcularDuracaoTotal();

    public Double calcularScore() {
        Double positivos = 0.0;
        Integer total = reviews.size();

        for (Boolean review : reviews) {
            if (review) {
                positivos++;
            }
        }

        return (positivos / total) * 100.0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Boolean> getReviews() {
        return reviews;
    }

    public void setReviews(List<Boolean> reviews) {
        this.reviews = reviews;
    }

    public Integer getClassificacaoEtaria() {
        return classificacaoEtaria;
    }

    public void setClassificacaoEtaria(Integer classificacaoEtaria) {
        this.classificacaoEtaria = classificacaoEtaria;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }
}

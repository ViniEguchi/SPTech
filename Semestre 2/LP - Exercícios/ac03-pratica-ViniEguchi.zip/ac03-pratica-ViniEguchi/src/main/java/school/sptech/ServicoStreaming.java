package school.sptech;

import java.util.ArrayList;
import java.util.List;

public class ServicoStreaming {
    private String nome;
    private List<Midia> midias;

    public ServicoStreaming() {
        midias = new ArrayList<>();
    }

    public void adicionar(Midia midia) {
        midias.add(midia);
    }

    public Integer duracaoTotalPlataforma() {
        return midias.stream()
                .mapToInt(Midia::calcularDuracaoTotal)
                .sum();
    }

    public List<Midia> listarPorScoreMaior(Double score) {
        List<Midia> resultado = new ArrayList<>();

        for (Midia midia : midias) {
            if (midia.calcularScore() > score) {
                resultado.add(midia);
            }
        }

        return resultado;
    }

    public List<Midia> listarPorGenero(Genero genero) {
        return midias.stream()
                .filter(midia -> midia.getGenero().equals(genero))
                .toList();
    }

    public List<Filme> listarFilmesPorGenero(Genero genero) {
        List<Filme> resultado = new ArrayList<>();

        for (Midia midia : midias) {
            if (midia instanceof Filme filme) {
                if (filme.getGenero().equals(genero)) {
                    resultado.add(filme);
                }
            }
        }

        return resultado;
    }

    public Serie buscarSerieComMaisEpisodios() {
        Serie serie = null;
        Integer qtdEpisodios = 0;

        for (Midia midia : midias) {
            if (midia instanceof Serie s) {
                if (s.getEpisodios() > qtdEpisodios) {
                    qtdEpisodios = s.getEpisodios();
                    serie = s;
                }
            }
        }

        return serie;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Midia> getMidias() {
        return midias;
    }

    public void setMidias(List<Midia> midias) {
        this.midias = midias;
    }
}

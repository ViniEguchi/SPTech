[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/ySP_dL2G)
# Avaliação Continuada 03 - Prática 📎

## Orientações Gerais: 🚨

1. Utilize **apenas** tipos **wrapper** para criar atributos e métodos.
2. **Respeite** os nomes de atributos e métodos definidos no exercício.
3. Tome **cuidado** com os **argumentos** especificados no exercício.
   **Não** adicione argumentos não solicitados e mantenha a ordem definida no enunciado.
4. Verifique se **não** há **erros de compilação** no projeto antes de enviar.
5. As classes devem seguir as regras de encapsulamento.
6. Deixe um **construtor vazio** para utilização nos testes unitários.

## Case: Streaming 🎥

Olá caro desenvolvedor,

Você foi contratado para desenvolver um sistema que irá catalogar diversos filmes e séries de
diferentes serviços de streaming.

Aqui está a especificação das classes do sistema:

![diagrama.png](diagrama.png)

### Métodos da classe `Midia`:

* `calcularDuracaoTotal`:
    * método abstrato que deve ser implementado nas classes filhas.


* `calcularScore`:
  * Calcula o score do Rotten Tomatoes conforme as reviews do filme ou série.
  * O atributo reviews armazena cada review como valor boolean em uma `ArrayList`.
    * true: review positiva
    * false: review negativa
  * O método deve retornar o score de 0 a 100, conforme o número de reviews positivas e negativas.
  * **Cuidado:** converta os valores para double, caso contrário o Java fará a divisão inteira.
  * Exemplo:
    * reviews = [true, true, false, true]
    * score = 3.0 / 4.0 * 100.0 = 75.0
  * **Atenção:** Não há testes unitários desse método na classe `Midia`. Ele será validado de forma indireta no método `listarPorScoreMaior` da classe `ServicoStreaming`. Caso ache necessário, teste manualmente.

### Métodos da classe `Filme`:

* `calcularDuracaoTotal`:
    * deve retornar a duração do filme com créditos.

### Métodos da classe `Serie`:

* `calcularDuracaoTotal`:
    * deve retornar a duração total da série (duração de todos os episódios).
    * **OBS:** o atributo ``episodio`` já contempla todos os episódios da série, não é necessário calcular
      com temporadas.

### Métodos da classe `ServicoStreaming`:

* `adicionar`:
    * deve adicionar uma mídia ao serviço de streaming.


* `duracaoTotalPlataforma`:
    * deve retornar a duração total de todas as mídias cadastradas no serviço de streaming.


* `listarPorScoreMaior`:
    * deve retornar uma lista com todas as mídias que possuem um score maior que o score passado como
      argumento.


* `listarPorGenero`:
    * deve retornar uma lista com todas as mídias que possuem o gênero passado como argumento.


* `listarFilmesPorGenero`:
    * deve retornar uma lista com todos os filmes que possuem o gênero passado como argumento.


* `buscarSerieComMaisEpisodios`:
    * deve retornar a série com maior quantidade de episódios. Caso não tenha nenhuma serie no
      serviço de streaming, retorne nulo.

### Atenção: o uso de stream não é obrigatório.

### Boa sorte! 🚀

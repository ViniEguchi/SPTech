package school.sptech;

public class Cinema {

    Boolean validarSala(Integer sala) {

        if (sala < 1 || sala > 4) {

            return false;
        }
        return true;
    }

    Double calcularValorIngresso(Integer sala, Boolean meiaEntrada) {

        Integer meia = 1;

        if (meiaEntrada) {

            meia = 2;
        }

        if (sala.equals(1)) {

            return 30.0 / meia;
        } else if (sala.equals(2)) {

            return 35.0 / meia;
        } else if (sala.equals(3)) {

            return 40.0 / meia;
        } else if (sala.equals(4)) {

            return 45.0 / meia;
        } else {

            return 0.0;
        }
    }

    Double calcularLucroTotal(Integer[] salas, Boolean[] estudantes) {

        Double lucro = 0.0;
        Integer meia;

        for (int i = 0; i < salas.length; i++) {

            meia = 1;

            if (estudantes[i]) {

                meia =2;
            }

            if (salas[i].equals(1)) {

                lucro += 30.0 / meia;
            } else if (salas[i].equals(2)) {

                lucro += 35.0 / meia;
            } else if (salas[i].equals(3)) {

                lucro += 40.0 / meia;
            } else if (salas[i].equals(4)) {

                lucro += 45.0 / meia;
            } else {

                lucro += 0.0;
            }
        }

        return lucro * 0.1;
    }

    String calcularSeloTomatometro(Boolean[] reviews) {

        Double fresh = 0.0;

        for (Boolean review : reviews) {

            if (review) {

                fresh++;
            }
        }

        Double avaliacao = (fresh / reviews.length) * 100.0;

        if (avaliacao >= 60) {

            return "fresh";
        }

        return "rotten";
    }
}
package school.sptech.provider;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;

import java.util.stream.Stream;

public class CalcularSeloTomatometroProvider implements ArgumentsProvider {

    @Override
    public Stream<? extends Arguments> provideArguments(ExtensionContext extensionContext) throws Exception {
        return Stream.of(
                Arguments.of(new Boolean[]{true, true, true, true, false}, "fresh"), // 80% Fresh
                Arguments.of(new Boolean[]{true, false, false, false, false}, "rotten"), // 20% Fresh
                Arguments.of(new Boolean[]{true, true, true, false, false}, "fresh"), // 60% Fresh
                Arguments.of(new Boolean[]{true, true, false, false, false}, "rotten"), // 40% Fresh
                Arguments.of(new Boolean[]{true, true, true, true, true}, "fresh"), // 100% Fresh
                Arguments.of(new Boolean[]{false, false, false, false, false}, "rotten"), // 0% Fresh
                Arguments.of(new Boolean[]{true, true, false, true, true, false}, "fresh"), // 66.7% Fresh
                Arguments.of(new Boolean[]{false, false, false, true, false, false}, "rotten"), // 16.7% Fresh
                Arguments.of(new Boolean[]{true, true, true, true, false, false, false, false, false, false}, "rotten"), // 40% Fresh
                Arguments.of(new Boolean[]{true, true, true, true, false, false, false, false, true, true}, "fresh"), // 60% Fresh
                Arguments.of(new Boolean[]{true, false, true, false, true, false, true, false, true, false}, "rotten"), // 50% Fresh
                Arguments.of(new Boolean[]{true, true, true, false, true, true, true, false, false, false}, "fresh"), // 60% Fresh
                Arguments.of(new Boolean[]{false, false, false, false, true, true, true, true, false, false}, "rotten"), // 40% Fresh
                Arguments.of(new Boolean[]{}, "rotten") // Caso vazio tratado como 0% Fresh
        );
    }
}
